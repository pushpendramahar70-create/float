package com.dark;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.provider.Settings;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.dark.utils.AppManager;
import com.dark.utils.Downtwo;

import org.lsposed.lsparanoid.Obfuscate;

import java.io.File;
import java.util.Locale;

import net_62v.external.MetaActivationManager;
import net_62v.external.MetaActivityManager;
import net_62v.external.MetaStorageManager;

@Obfuscate
public class MAct extends AppCompatActivity {

    static {
        try {
            System.loadLibrary("dark");
        } catch (UnsatisfiedLinkError ignored) {}
    }

    private static final String PKG_BGMI = "com.pubg.imobile";
    private static final String PREF_NAME = "com.dark.download";
    private static final String PREF_VERSION_KEY = "version";

    // UI
    private ProgressBar downloadProgressBar;
    private TextView downloadStatusText;
    private TextView percentText;
    private View downloadBox;
    private View restartButton;
    private ProgressBar loadingCursor;
    private TextView appVersionText;
    
    private TextView startText;
    private ImageView actionIcon;
    private View startBgmi;
    private View statusToggle;
    private View statusLoader;
    private ImageView statusErrorIcon;
    private TextView statusToggleText;

    private TextView gameName;
    private TextView packageName;
    private TextView gameStatus;
    private TextView expiryDays;
    private TextView expiryHours;
    private TextView expiryMinutes;
    private TextView expirySeconds;
    private final Handler expiryHandler = new Handler();
    private final Runnable expiryTicker = this::updateExpiryCountdown;

    private View obbButton;
    private boolean isObbCopied = false;
    private boolean isGameRunning = false;
    private boolean isGameInstalled = false;
    private boolean isUpdateAvailable = false;

    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setStatusBarColor(Color.TRANSPARENT);
            getWindow().getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
            );
        }

        setContentView(R.layout.activity_main);

        View mainCard = findViewById(R.id.mainCard);
        if (mainCard != null) {
            mainCard.setAlpha(0f);
            mainCard.setTranslationY(200f);
            mainCard.animate().alpha(1f).translationY(0f).setDuration(1000).start();
        }
        checkPermissions();

        // Download UI
        downloadBox = findViewById(R.id.downloadBox);
        downloadProgressBar = findViewById(R.id.downloadProgressBar);
        downloadStatusText = findViewById(R.id.downloadStatusText);
        percentText = findViewById(R.id.percentText);
        restartButton = findViewById(R.id.restartButton);
        loadingCursor = findViewById(R.id.loadingCursor);
        appVersionText = findViewById(R.id.appVersionText);

        // Action UI
        startText = findViewById(R.id.startText);
        actionIcon = findViewById(R.id.actionIcon);
        startBgmi = findViewById(R.id.startBgmi);
        gameName = findViewById(R.id.gameName);
        packageName = findViewById(R.id.packageName);
        gameStatus = findViewById(R.id.gameStatus);
        statusToggle = findViewById(R.id.statusToggle);
        statusLoader = findViewById(R.id.statusLoader);
        statusErrorIcon = findViewById(R.id.statusErrorIcon);
        statusToggleText = findViewById(R.id.statusToggleText);

        obbButton = findViewById(R.id.obbButton);

        checkObbApplied();
        updateGameStatus();
        updateVersionDisplay();
        setupExpiryCountdown();

        if (obbButton != null) {
            obbButton.setOnClickListener(v -> copyObbFiles());
        }

        if (restartButton != null) {
            restartButton.setOnClickListener(v -> restartApp());
        }

        if (startBgmi != null) {
            startBgmi.setOnClickListener(v -> {
                if (isUpdateAvailable) {
                    startDownload();
                } else if (!isGameInstalled) {
                    installGame();
                } else if (isGameRunning) {
                    stopGame();
                } else {
                    handleLaunchFlow();
                }
            });
        }

        // Start Workflow: Update Check -> Download Files (if needed)
        startWorkflow();
    }

    private void updateVersionDisplay() {
        SharedPreferences prefs = getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        String localVersion = prefs.getString(PREF_VERSION_KEY, "1.0");
        if (appVersionText != null) {
            appVersionText.setText("Version " + localVersion);
        }
    }

    private void startWorkflow() {
        // Keep launch locked while the server/local version comparison is pending.
        isUpdateAvailable = true;
        runOnUiThread(() -> {
            if (downloadBox != null) downloadBox.setVisibility(View.VISIBLE);
            if (downloadStatusText != null) downloadStatusText.setText("Checking for update...");
            if (percentText != null) percentText.setText("WAIT");
            if (startText != null) startText.setText("CHECKING UPDATE...");
            if (downloadProgressBar != null) {
                downloadProgressBar.setIndeterminate(true);
            }
            if (restartButton != null) restartButton.setVisibility(View.GONE);
            if (loadingCursor != null) loadingCursor.setVisibility(View.VISIBLE);
        });

        Downtwo checkTask = new Downtwo(this, success -> {
            File libFile = new File(getFilesDir(), "loader/libbgmi.so");
            SharedPreferences prefs = getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
            String localVersion = prefs.getString(PREF_VERSION_KEY, "0.0");

            if (!libFile.exists() || "0.0".equals(localVersion)) {
                // First time or missing files - download latest
                startDownload();
            } else {
                // Check if server version is different from local
                new Downtwo(this, updateSuccess -> {}) {
                    @Override
                    protected void onPostExecute(String result) {
                        // Keep the update gate active for every server/local mismatch.
                        // Do not let last_notified_version hide an update that has not
                        // actually been downloaded yet.
                        String serverVer = getFetchedServerVersion();
                        if (serverVer == null) {
                            isUpdateAvailable = true;
                            runOnUiThread(() -> {
                                if (downloadStatusText != null) downloadStatusText.setText("Update check failed");
                                if (startText != null) startText.setText("RETRY UPDATE");
                                if (loadingCursor != null) loadingCursor.setVisibility(View.GONE);
                            });
                            return;
                        }
                        boolean updatePending = serverVer != null && !serverVer.equals(localVersion);
                        if (updatePending) {
                            isUpdateAvailable = true;
                            runOnUiThread(() -> {
                                if (downloadStatusText != null) downloadStatusText.setText("Update Available");
                                if (percentText != null) percentText.setText("NEW");
                                if (startText != null) startText.setText("UPDATE AVAILABLE");
                                if (downloadProgressBar != null) {
                                    downloadProgressBar.setIndeterminate(false);
                                    downloadProgressBar.setProgress(100);
                                }
                                if (loadingCursor != null) loadingCursor.setVisibility(View.GONE);
                            });
                        } else {
                            // Only the matching server/local version can unlock launch.
                            isUpdateAvailable = false;
                            runOnUiThread(() -> {
                                updateButtonState(false);
                                if (downloadStatusText != null) downloadStatusText.setText("Version Up to Date");
                                new Handler().postDelayed(() -> {
                                    if (downloadBox != null && !isGameRunning) downloadBox.setVisibility(View.GONE);
                                }, 1500);
                            });
                        }
                    }
                }.execute(Downtwo.Link(), "check_only");
            }
        });
        checkTask.execute(Downtwo.Link(), "check_only");
    }

    private void startDownload() {
        runOnUiThread(() -> {
            if (downloadBox != null) downloadBox.setVisibility(View.VISIBLE);
            if (startText != null) startText.setText("UPDATING...");
            if (restartButton != null) restartButton.setVisibility(View.GONE);
            if (loadingCursor != null) loadingCursor.setVisibility(View.VISIBLE);
        });

        Downtwo task = new Downtwo(this, success -> {
            if (success) {
                runOnUiThread(() -> {
                    isUpdateAvailable = false;
                    if (downloadStatusText != null) downloadStatusText.setText("Update Done");
                    if (percentText != null) percentText.setText("100%");
                    if (downloadProgressBar != null) downloadProgressBar.setProgress(100);
                    if (loadingCursor != null) loadingCursor.setVisibility(View.GONE);
                    
                    updateVersionDisplay(); // Refresh version text after update
                    updateButtonState(false); // Unlock Launch only after the download succeeds
                    
                    if (restartButton != null) {
                        restartButton.setVisibility(View.VISIBLE);
                        restartButton.setAlpha(0f);
                        restartButton.animate().alpha(1f).setDuration(500).start();
                    }
                });
            } else {
                runOnUiThread(() -> {
                    Toast.makeText(this, "Update Failed", Toast.LENGTH_SHORT).show();
                    if (startText != null) startText.setText("RETRY UPDATE");
                });
            }
        });

        task.setProgressListener(progress -> runOnUiThread(() -> {
            if (downloadProgressBar != null) {
                downloadProgressBar.setIndeterminate(false);
                downloadProgressBar.setMax(100);
                downloadProgressBar.setProgress(progress);
            }
            if (percentText != null) percentText.setText(progress + "%");
            if (downloadStatusText != null) downloadStatusText.setText("Downloading Update...");
        }));
        
        task.execute(Downtwo.Link());
    }

    private void restartApp() {
        Intent intent = getPackageManager().getLaunchIntentForPackage(getPackageName());
        if (intent != null) {
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
            Runtime.getRuntime().exit(0);
        }
    }

    private void setupExpiryCountdown() {
        expiryDays = findViewById(R.id.expiryDays);
        expiryHours = findViewById(R.id.expiryHours);
        expiryMinutes = findViewById(R.id.expiryMinutes);
        expirySeconds = findViewById(R.id.expirySeconds);
        SharedPreferences prefs = getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        if (!prefs.contains("expiry_at")) {
            long expiryAt = System.currentTimeMillis() + (30L * 24L * 60L * 60L * 1000L);
            prefs.edit().putLong("expiry_at", expiryAt).apply();
        }
        updateExpiryCountdown();
    }

    private void updateExpiryCountdown() {
        if (expiryDays == null) return;
        long expiryAt = getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE).getLong("expiry_at", System.currentTimeMillis());
        long remaining = Math.max(0L, expiryAt - System.currentTimeMillis());
        long totalSeconds = remaining / 1000L;
        long days = totalSeconds / 86400L;
        long hours = (totalSeconds % 86400L) / 3600L;
        long minutes = (totalSeconds % 3600L) / 60L;
        long seconds = totalSeconds % 60L;
        expiryDays.setText(String.format(Locale.US, "%02d", days));
        expiryHours.setText(String.format(Locale.US, "%02d", hours));
        expiryMinutes.setText(String.format(Locale.US, "%02d", minutes));
        expirySeconds.setText(String.format(Locale.US, "%02d", seconds));
        expiryHandler.removeCallbacks(expiryTicker);
        expiryHandler.postDelayed(expiryTicker, 1000L);
    }

    private void checkObbApplied() {
        new Thread(() -> {
            try {
                PackageInfo info = getPackageManager().getPackageInfo(PKG_BGMI, 0);
                String gameObb = "main." + info.versionCode + "." + PKG_BGMI + ".obb";
                String destPath = MetaStorageManager.obtainAppExternalStorageDir(PKG_BGMI) + "/Android/obb/" + PKG_BGMI;
                File destFile = new File(destPath, gameObb);
                if (destFile.exists()) {
                    isObbCopied = true;
                    runOnUiThread(() -> { if (obbButton != null) obbButton.setVisibility(View.GONE); });
                }
            } catch (Exception ignored) {}
        }).start();
    }

    private void updateGameStatus() {
        isGameInstalled = false;
        try {
            PackageInfo packageInfo = getPackageManager().getPackageInfo(PKG_BGMI, 0);
            if (packageInfo != null) {
                isGameInstalled = true;
                if (gameName != null) gameName.setText("Battlegrounds India");
                if (packageName != null) packageName.setText(PKG_BGMI);
                if (gameStatus != null) gameStatus.setText("Ready to launch");
                updateButtonState(false);
            }
        } catch (Exception ignored) {
            isGameInstalled = false;
            if (gameStatus != null) gameStatus.setText("Not Installed");
            if (startText != null) {
                startText.setText("INSTALL GAME");
                startText.setTextColor(Color.parseColor("#D8DEE8"));
            }
            if (actionIcon != null) {
                actionIcon.setImageResource(android.R.drawable.ic_menu_save);
                actionIcon.setColorFilter(Color.parseColor("#D8DEE8"));
            }
        }
    }

    private void updateButtonState(boolean running) {
        isGameRunning = running;
        runOnUiThread(() -> {
            if (running) {
                if (startText != null) {
                    startText.setText("STOP GAME");
                    startText.setTextColor(Color.parseColor("#FF5C86"));
                }
                if (actionIcon != null) {
                    actionIcon.setImageResource(android.R.drawable.ic_delete);
                    actionIcon.setColorFilter(Color.parseColor("#FF5C86"));
                }
                if (startBgmi != null) {
                    startBgmi.setBackgroundResource(R.drawable.bg_ref_stop_button);
                }
                if (downloadBox != null) {
                    downloadBox.setVisibility(View.VISIBLE);
                    if (downloadStatusText != null) downloadStatusText.setText("Game Running...");
                    if (percentText != null) percentText.setText("ACTIVE");
                    if (downloadProgressBar != null) {
                        downloadProgressBar.setIndeterminate(true);
                        downloadProgressBar.setProgress(100);
                    }
                    if (restartButton != null) restartButton.setVisibility(View.GONE);
                }
            } else {
                if (isUpdateAvailable) {
                    if (startText != null) {
                        startText.setText("UPDATE AVAILABLE");
                        startText.setTextColor(Color.parseColor("#D8DEE8"));
                    }
                } else {
                    if (startText != null) {
                        startText.setText("LAUNCH");
                        startText.setTextColor(Color.parseColor("#D8DEE8"));
                    }
                }
                if (actionIcon != null) {
                    actionIcon.setImageResource(android.R.drawable.ic_media_play);
                    actionIcon.setColorFilter(Color.parseColor("#D8DEE8"));
                }
                if (startBgmi != null) {
                    startBgmi.setBackgroundResource(R.drawable.bg_ref_launch_button);
                }
                if (downloadBox != null) {
                    new Handler().postDelayed(() -> {
                        if (!isGameRunning && !isUpdateAvailable) downloadBox.setVisibility(View.GONE);
                    }, 1000);
                }
            }
        });
    }

    private void handleLaunchFlow() {
        try {
            if (!MetaActivationManager.getActivationStatus()) {
                showStatusToggle("LAUNCHING FAILED", true);
                return;
            }
        } catch (Exception ignored) {
            showStatusToggle("LAUNCHING FAILED", true);
            return;
        }

        File libFile = new File(getFilesDir(), "loader/libbgmi.so");
        if (!libFile.exists()) {
            startDownload();
            return;
        }

        if (!isObbCopied) {
            copyObbFiles();
        } else {
            showStatusToggle("LAUNCHING BGMI", false);
            new Handler().postDelayed(() -> {
                hideStatusToggle();
                launchGame();
            }, 2500);
        }
    }

    private void showStatusToggle(String message, boolean isError) {
        if (statusToggle == null) return;
        
        runOnUiThread(() -> {
            statusToggle.setVisibility(View.VISIBLE);
            statusToggle.setAlpha(0f);
            statusToggle.animate().alpha(1f).setDuration(300).start();
            
            if (statusToggleText != null) {
                statusToggleText.setText(message);
                statusToggleText.setTextColor(isError ? Color.parseColor("#FF5C86") : Color.WHITE);
            }
            
            if (statusLoader != null) {
                statusLoader.setVisibility(isError ? View.GONE : View.VISIBLE);
            }
            
            if (statusErrorIcon != null) {
                statusErrorIcon.setVisibility(isError ? View.VISIBLE : View.GONE);
            }
            
            if (isError) {
                new Handler().postDelayed(this::hideStatusToggle, 3000);
            }
        });
    }

    private void hideStatusToggle() {
        if (statusToggle == null) return;
        
        runOnUiThread(() -> {
            statusToggle.animate().alpha(0f).setDuration(300).withEndAction(() -> {
                statusToggle.setVisibility(View.GONE);
            }).start();
        });
    }

    private void launchGame() {
        try {
            Intent intent = MetaActivityManager.obtainSplashLaunchIntent(PKG_BGMI, this);
            if (intent != null) {
                startActivity(intent);
                updateButtonState(true);
            }
        } catch (Exception e) {
            Log.e("MAct", "Launch error", e);
        }
    }

    private void stopGame() {
        try {
            MetaActivityManager.killAppByPkg(PKG_BGMI);
            updateButtonState(false);
        } catch (Exception e) {
            Toast.makeText(this, "Stop Failed: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    private void installGame() {
        try {
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setData(Uri.parse("market://details?id=" + PKG_BGMI));
            startActivity(intent);
        } catch (Exception e) {
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setData(Uri.parse("https://play.google.com/store/apps/details?id=" + PKG_BGMI));
            startActivity(intent);
        }
    }

    private void copyObbFiles() {
        if (obbButton == null) return;
        
        Button btn = (Button) obbButton;
        btn.setEnabled(false);
        btn.setText("PROCESSING...");
        
        AppManager appManager = new AppManager(this);
        appManager.copyObbFolderAsync(PKG_BGMI, new AppManager.CopyCallback() {
            @Override
            public void onCopyCompleted(boolean success) {
                runOnUiThread(() -> {
                    if (success) {
                        isObbCopied = true;
                        btn.setVisibility(View.GONE);
                        Toast.makeText(MAct.this, "OBB Copied Successfully", Toast.LENGTH_SHORT).show();
                    } else {
                        btn.setEnabled(true);
                        btn.setText("APPLY OBB");
                        Toast.makeText(MAct.this, "OBB Copy Failed", Toast.LENGTH_SHORT).show();
                    }
                });
            }

            @Override
            public void onProgressUpdate(int progress) {
                runOnUiThread(() -> {
                    btn.setText("PROCESSING " + progress + "%");
                });
            }
        }, false); // false to hide the default dialog
    }

    private void checkPermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 100);
            }
        }
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            if (!Environment.isExternalStorageManager()) {
                Intent intent = new Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION);
                startActivity(intent);
            }
        }
    }
}
