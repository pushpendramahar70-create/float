package com.dark;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.animation.DecelerateInterpolator;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class SplashActivity extends AppCompatActivity {
    private final Handler handler = new Handler();
    private final Runnable openLogin = () -> {
        if (isFinishing()) return;
        startActivity(new Intent(SplashActivity.this, LogAct.class));
        finish();
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(android.graphics.Color.rgb(5, 4, 10));
        getWindow().setNavigationBarColor(android.graphics.Color.rgb(5, 4, 10));
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
        setContentView(R.layout.activity_splash);
        ImageView logo = findViewById(R.id.splashLogo);
        View brand = findViewById(R.id.splashBrand);
        TextView admin = findViewById(R.id.splashAdmin);
        TextView xCheat = findViewById(R.id.splashXCheat);
        if (logo != null) {
            logo.setAlpha(0f);
            logo.setScaleX(0.82f);
            logo.setScaleY(0.82f);
            logo.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(700L).setInterpolator(new DecelerateInterpolator()).start();
        }
        if (brand != null) {
            brand.setAlpha(1f);
        }
        if (admin != null) {
            admin.setAlpha(0f);
            admin.setTranslationX(-420f);
            admin.animate().alpha(1f).translationX(0f).setDuration(1400L).setStartDelay(220L).setInterpolator(new DecelerateInterpolator(1.6f)).start();
        }
        if (xCheat != null) {
            xCheat.setAlpha(0f);
            xCheat.setTranslationX(420f);
            xCheat.animate().alpha(1f).translationX(0f).setDuration(1400L).setStartDelay(220L).setInterpolator(new DecelerateInterpolator(1.6f)).start();
        }
        handler.postDelayed(openLogin, 3200L);
    }

    @Override protected void onDestroy() {
        handler.removeCallbacks(openLogin);
        super.onDestroy();
    }
}
