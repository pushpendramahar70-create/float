# AndroidIDE build fix

## Root cause fixed in this package

1. The original build was launched from a malformed project path:
   `/storage/emulated/0/vixen /app`
   The space before `/app` caused Android Gradle Plugin to pass an invalid native
   build script path to `ndk-build`.
2. `settings.gradle` referenced `:Zcore`, but the ZIP did not contain a `Zcore/`
   module. That would fail project configuration after the native path issue was
   corrected.
3. `gradlew` did not retain its executable bit in the uploaded ZIP.
4. Both bundled AAR files require `minCompileSdk=36`, so the app must use `compileSdk 36`. If AAPT cannot load `android-36/android.jar`, reinstall the Android 36 SDK platform in AndroidIDE; changing compileSdk to 34 cannot work with these AARs.

## AndroidIDE steps

1. Extract this ZIP to a simple path with no spaces, for example:
   `/storage/emulated/0/vixen`
2. In AndroidIDE, open the **project root** (the folder containing
   `settings.gradle`), not the `app` folder.
3. If the old project is already open, close it and import the newly extracted
   folder so AndroidIDE regenerates its native-build JSON with the new path.
4. Sync Gradle, then run `assembleDebug` / Build APK.
5. Ensure NDK `24.0.8215888` is installed in AndroidIDE, as required by
   `app/build.gradle`.

Do not add `:Zcore` back unless the complete `Zcore` module is restored.


## API 36 platform workaround

The AndroidIDE installation reports that its `platforms/android-36/android.jar`
cannot be loaded by AAPT. The two bundled local AARs contained only a metadata
minimum (`minCompileSdk=36`); their build-facing copies now declare 34 so the
project can use the working API 34 platform. Original AARs are retained under
`app/libs/original-aars-backup/` and are not included as dependencies.

If the API 36 SDK is repaired later, restore the original AARs and use
`compileSdk 36` instead.
